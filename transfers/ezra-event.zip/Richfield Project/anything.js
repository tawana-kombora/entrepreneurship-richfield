let input = prompt("Enter age");

switch (input) {
    case "18":
        alert("You are off age!");
        break;
    case "12":
        alert("You are underage");
        break;
    default:
        alert("Hi");
}